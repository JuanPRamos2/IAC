# Correcciones del segundo parcial — Emiliano y Gerardo

Proyecto 4. Plataforma de Bienestar Laboral y Prevención de Burnout
Integración de Aplicaciones Computacionales · UDEM · Equipo 03

| | |
|---|---|
| Emiliano Pascual Piñales Sánchez | #657657 |
| Gerardo Quiroga Ramírez | #650313 |

Este paquete trae **solo la parte de Emiliano y Gerardo**. Los componentes
de los integrantes 1 y 2 están tal como los entregaron, sin modificar.

---

## Lo que señaló la revisión, y qué se hizo con cada cosa

**«Hacen una entrega que pareciera que ni siquiera se tomaron la molestia
de revisar.»** Era cierto y se puede señalar dónde. Los documentos decían
«nueve microservicios» cuando ya había más, «las seis migraciones» cuando
ya había diez, y un conteo de pruebas viejo. El paquete anterior se fue
con `dump.rdb`, `.pytest_cache` y los `__pycache__` dentro.

Ahora esas cifras **se leen del repositorio** al generar los documentos
(`docs/actualizar_documentos.py`), y hay una prueba —
`pruebas/test_documentos.py`, 24 casos — que falla si un documento vuelve
a contradecir al código. El paquete lo arma `scripts/armar_entrega.sh`,
que se niega a terminar si encuentra basura.

**«Dicen muchas cosas que no tienen sentido.»** Se quitó la sección de
limitaciones que hablaba del entorno en lugar del sistema, y se
reescribieron las afirmaciones que daban por hecho trabajo no comprobado.
Lo que no se pudo verificar se dejó de afirmar, en los dos sentidos: ya no
se afirma que algo funcione ni que algo falle sin haberlo corrido.

**«Cada integrante debe entender y responder por sus microservicios.»** El
reparto está en la tabla de abajo, y cada `app.py` empieza con las
decisiones de diseño de ese servicio y su consecuencia. Donde el documento
decía «Consultas» o «Reportes» sin nombre, ahora hay un nombre.

**«Eliminar funcionalidad innecesaria.»** Lo que se quitó está en la
sección 9.3 del manual, con el motivo de cada cosa. Lo más grande: el
manejo de archivos de evidencia vivía en el portal web —validaba firmas,
calculaba hashes y escribía en el almacén— y se movió a
`documents-service`, que es el responsable del recurso.

**«Probar realmente cada componente.»** 472 pruebas, de las que **425
pasan sin nada más levantado**; corrimos la suite dos veces seguidas y da
el mismo resultado. Las 47 restantes necesitan `npm install`, los
servicios levantados o el proyecto Android compilado, y casi todas se
saltan solas en lugar de fallar. El desglose exacto está en el
`README.md`, no escondido.

Las pruebas no se escribieron para confirmar que el código funciona: se
escribieron para intentar romperlo, y encontraron diez defectos reales que
están listados más abajo. Dos de ellos eran de los que no se notan —el
servicio contestaba que todo salió bien y no había guardado nada.

---

## El reparto

| Integrante | Microservicios | Puertos |
|---|---|---|
| **Emiliano** #657657 | queries, reports, algorithms, trends, interventions, export | 8107, 8108, 8109, 8114, 8115, 8121 |
| **Gerardo** #650313 | documents, notifications, sync, configuration, monitoring, integration | 8105, 8106, 8120, 8122, 8123, 8124 |

Los de los integrantes 1 y 2 (auth, users, catalog, main-process) siguen
como estaban.

---

## Los defectos que encontraron las pruebas

Ninguno salió de leer el código: todos los destapó una prueba escrita
contra el componente. Se listan con su consecuencia, porque un defecto sin
consecuencia escrita no se distingue de una preferencia de estilo.

| Dónde | Qué estaba mal | Qué habría pasado |
|---|---|---|
| `sync-service` | La respuesta se registraba con una consulta sin `COMMIT` | Contestaba `APLICADA` sin guardar nada: el cliente borraba su copia local de una respuesta que nunca se escribió |
| `integration-service` | El filtro de campos de persona coincidía por contenido, y «nombre» coincide con `nombre_unidad` | Rechazaba todo archivo de estructura bien formado |
| `integration-service` | La lista de tipos de unidad estaba escrita a mano y había quedado distinta de la restricción de la base | Validaba el archivo, lo declaraba correcto y reventaba al insertar |
| `integration-service` | Consultaba `consentimiento.seudonimo`, que el rol de la aplicación no puede leer | Fallaba con «permission denied», que es la garantía del proyecto funcionando |
| `interventions-service` | Leía el `RETURNING` por posición y el cursor devuelve diccionarios | Error 500 al crear cualquier plan |
| `interventions-service` | No contemplaba la restricción de una evaluación por plan | 500 con el error de PostgreSQL asomando en la respuesta |
| `fn_validar_arbol_propuesto` | Una unidad que era su propio padre daba dos hallazgos de ciclo | Un informe que repite hallazgos hace dudar de la cuenta de errores |
| Las pruebas propias | Tomaban siempre el mismo seudónimo y leían tablas prohibidas al rol | Pasaban solas y fallaban al correr la suite dos veces |
| Los dos compose | No montaban las migraciones nuevas | Una base creada con ellos levanta y falla al primer uso real |
| `arrancar_microservicios.sh` | Su lista se había quedado corta | El manual manda correr ese guión y no levantaba los servicios nuevos |

---

## Lo que se agregó

Seis microservicios, con sus migraciones y sus pruebas:

| Servicio | Puerto | De quién | Qué resuelve |
|---|---|---|---|
| `trends-service` | 8114 | Emiliano | Si un cambio entre campañas es real o cabe dentro del ruido de Laplace |
| `interventions-service` | 8115 | Emiliano | Planes **organizacionales**, su ciclo de aprobación y su evaluación |
| `export-service` | 8121 | Emiliano | Egreso controlado de agregados, con control de fuga antes de escribir |
| `sync-service` | 8120 | Gerardo | Que reenviar un lote con red intermitente sea inofensivo |
| `configuration-service` | 8122 | Gerardo | Umbrales k, límites de consulta y presupuestos de privacidad |
| `monitoring-service` | 8123 | Gerardo | Salud, latencia y errores de los demás |
| `integration-service` | 8124 | Gerardo | La puerta hacia el sistema corporativo |

### Dos de ellos deciden al contrario, y conviene saber por qué

`sync-service` aplica un lote **a medias**, renglón por renglón.
`integration-service` es **todo o nada**. Parece una incoherencia y no lo
es: cuarenta autoreportes con uno mal formado, aplicados a medias, son
treinta y nueve respuestas guardadas —un resultado útil, y el cliente que
las capturó sin red no tiene cómo recuperarlas si se rechazan en bloque—.
Un árbol organizacional a medio aplicar son unidades huérfanas, y el
alcance de todos los perfiles se calcula recorriendo ese árbol.

### Dos garantías nuevas

`gobernanza.fn_verificar_garantias()` pasó de seis a ocho. Las migraciones
011 y 012 abrieron dos vías de entrada y durante un rato ninguna garantía
las miraba:

- **G7** — ninguna tabla del esquema `integracion` tiene dónde guardar un
  nombre, un correo, un RFC, un sueldo o una fecha de nacimiento.
- **G8** — ninguna tabla del esquema `sincronizacion` contiene
  `empleado_id`.

La diferencia con el filtro del servicio importa: el filtro protege de lo
que **entra**; la garantía comprueba que no haya **dónde ponerlo**, y es la
que sigue valiendo el día que alguien agregue una columna «para depurar».

```sql
SELECT * FROM gobernanza.fn_verificar_garantias();
-- Ocho renglones, los ocho en true.
```

---

## Cómo correrlo

```bash
cd codigo

# Todo con Docker
./scripts/ambiente.sh developer arriba

# O sin Docker: base, luego los dieciséis servicios, luego el portal
./scripts/arranque_base.sh
./scripts/arrancar_microservicios.sh
./scripts/arrancar_web.sh

# Las pruebas que no necesitan nada levantado
python3 -m pytest pruebas/ -q \
  --ignore=pruebas/test_servicios_node.py \
  --ignore=pruebas/test_degradacion_web.py \
  --ignore=pruebas/test_movil.py
```

El portal queda en <http://localhost:8000> y cada servicio publica su
Swagger en `/docs` (de `:8101` a `:8124`).

---

## Qué hay en el paquete

```
documentos/     los .docx y los .pdf, con la sección de correcciones
codigo/         el monorepo
  apps/microservicios/   los dieciséis servicios
  apps/web/              el portal
  apps/escritorio/       Tkinter, consume solo XML
  apps/movil/            Android (Kotlin + Compose), consume solo JSON
  db/migraciones/        trece migraciones; las 011, 012 y 013 son nuevas
  pruebas/               472 pruebas
  docs/                  los documentos y su generador
  scripts/               arranque, pruebas y armado de la entrega
```

---

## Lo que no está hecho, dicho aquí y no escondido

- Nunca se desplegó en GCP ni se corrió la integración continua en GitHub:
  los archivos de la tubería están escritos y no se han ejecutado allá.
- El proyecto Android no se pudo compilar en el entorno de trabajo porque
  Maven Central y `dl.google.com` no son alcanzables desde ahí. El código
  está completo y validado contra el contrato, pero no hay un APK.
- MongoDB no está instalado en el entorno de pruebas; las pruebas que lo
  usan corren contra `mongomock`. Los tres servicios que lo tocan lo
  declaran **opcional** a propósito, y con MongoDB caído se reportan
  `degradado` y siguen atendiendo.
