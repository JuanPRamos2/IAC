"""
Una evidencia que se carga y no se puede volver a encontrar no es evidencia.

POR QUE ESTE ARCHIVO EXISTE APARTE
----------------------------------
Las pruebas que ya había cubrían cargar el archivo y bajarlo POR SU SELLO.
Las dos pasaban, y aun así la pantalla de evidencias del portal decía «No
hay evidencias registradas todavía» justo después de cargar una con éxito.

Eran dos desajustes entre el portal y documents-service:

1. El portal pedía `tipo=REPORTE_ORGANIZACIONAL` y la carga guarda el
   documento como `EVIDENCIA_ARCHIVO`.
2. El sobre de paginación de este endpoint trae la lista bajo la clave
   `documentos` —`sobre_pagina(..., clave="documentos")`— y el portal
   leía `elementos`, que es el valor por omisión.

Ninguno de los dos levanta un error: `.get("elementos", [])` sobre un
sobre que trae `documentos` devuelve `[]` sin quejarse, y un filtro por un
tipo que no existe devuelve cero resultados, que es una respuesta
perfectamente válida. Por eso el sistema mentía en silencio.

Tampoco se veían bajando el archivo por su sello, porque esa ruta no pasa
por el listado. Lo que faltaba era probar el CAMINO COMPLETO —cargar,
listar, encontrar— y el contrato entre las dos piezas. Las pruebas de
contrato de aquí abajo LEEN del código del portal el tipo y la clave que
de verdad usa, en lugar de repetirlos: así, cambiar uno de los dos lados
rompe la prueba en vez de dejar la pantalla vacía.

UNA HIPOTESIS QUE RESULTO FALSA, Y LA PRUEBA QUE LA DEJA ANOTADA
-----------------------------------------------------------------
Al investigarlo supuse un tercer defecto: que `GET /documentos` no admitía
`INTERVENCION_SEGUIMIENTO` —el permiso con el que sí se puede cargar— y
que la especialista recibía un 403 mostrado como «no hay». Era falso: el
perfil «Especialista de bienestar» tiene además AGREGADO_GLOBAL e
INSTRUMENTO_ADMIN, así que siempre pudo listar. Ampliar los permisos del
listado habría abierto las evidencias de consentimiento sin arreglar
nada, así que no se hizo.

Lo que sí queda es el invariante que hacía falsa la hipótesis, escrito
como prueba: todo perfil que pueda CARGAR una evidencia tiene que poder
LISTARLA. Hoy se cumple por como están repartidos los permisos; si
mañana alguien crea un perfil de seguimiento sin permisos de consulta,
esta prueba falla antes de que la pantalla vuelva a decir que el trabajo
no existe.
"""
import base64
import os
import re

import pytest

from conftest import cab

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RUTA_PORTAL = os.path.join(RAIZ, "apps", "web", "app", "rutas", "evidencias.py")

# Permisos con los que `POST /api/v1/documentos/archivos` deja cargar.
PERMISOS_DE_CARGA = ("INTERVENCION_SEGUIMIENTO", "INTERVENCION_APROBAR",
                     "CONSENT_EVIDENCIA_AUDIT")
# Permisos con los que `GET /api/v1/documentos` deja listar.
PERMISOS_DE_LISTADO = ("CONSENT_EVIDENCIA_AUDIT", "BITACORA_CONSULTAR",
                       "INSTRUMENTO_ADMIN", "AGREGADO_GLOBAL")


def _fuente_del_portal():
    with open(RUTA_PORTAL, encoding="utf-8") as f:
        return f.read()


def _tipo_que_pide_el_portal():
    """El `tipo` con el que el portal consulta el listado, leído del código."""
    m = re.search(r'consulta\s*=\s*"\?tipo=([A-Z_]+)', _fuente_del_portal())
    assert m, ("No se pudo leer con que 'tipo' consulta el portal. Si la "
               "linea cambio de forma, actualiza esta prueba: sin ella el "
               "desajuste entre portal y servicio vuelve a ser mudo.")
    return m.group(1)


def _claves_que_lee_el_portal():
    """Las claves de la lista que el portal intenta leer del sobre."""
    m = re.search(r"for d in sobre\.get\(([^\n]+)\n", _fuente_del_portal())
    assert m, "No se pudo leer de que clave saca el portal la lista."
    return set(re.findall(r'"([a-z_]+)"', m.group(1)))


@pytest.fixture
def filas_sql():
    from test_procesos_integrales import filas
    return filas


@pytest.fixture
def evidencia_cargada(documentos, token_especialista, filas_sql):
    """Carga una evidencia real y devuelve lo que el servicio respondió."""
    plan = filas_sql("SELECT intervencion_id FROM intervencion.plan "
                     " WHERE estado IN ('APROBADA','EN_EJECUCION') "
                     " ORDER BY intervencion_id DESC LIMIT 1")
    if not plan:
        pytest.skip("no hay plan aprobado al que adjuntar evidencia")

    contenido = b"%PDF-1.4\n% acta de prueba de listado\n"
    r = documentos.post(
        "/api/v1/documentos/archivos", headers=cab(token_especialista),
        json={"intervencion_id": plan[0]["intervencion_id"],
              "nombre_archivo": "acta de listado.pdf",
              "descripcion": "Acta cargada para comprobar que se vuelve a encontrar.",
              "contenido_base64": base64.b64encode(contenido).decode()})
    assert r.status_code == 201, r.get_data(as_text=True)
    return r.get_json()


def test_la_evidencia_cargada_aparece_en_el_listado(
        documentos, token_especialista, evidencia_cargada):
    """Cargar y volver a encontrar, que es el camino que nadie probaba.

    Las pruebas que había bajaban el archivo por su sello, y esa ruta no
    pasa por el listado. Mientras no se recorriera el camino completo, el
    servicio podía guardar la evidencia correctamente y la pantalla seguir
    diciendo que no hay ninguna.
    """
    r = documentos.get("/api/v1/documentos?tipo=EVIDENCIA_ARCHIVO&tamano=50",
                       headers=cab(token_especialista))
    assert r.status_code == 200, r.get_data(as_text=True)

    ids = [d["documento_id"] for d in r.get_json()["documentos"]]
    assert evidencia_cargada["documento_id"] in ids, (
        "La evidencia se cargo (201, con su sello) y no aparece en el "
        "listado. Es el sintoma que la pantalla mostraba como 'No hay "
        "evidencias registradas todavia'.")


def test_el_tipo_que_pide_el_portal_es_el_que_el_servicio_guarda(
        documentos, token_especialista, evidencia_cargada):
    """El contrato entre las dos piezas, leído de las dos piezas.

    No se repite aquí el literal `EVIDENCIA_ARCHIVO`: se saca del código
    del portal y se confronta con lo que el servicio devuelve de verdad.
    Un filtro por un tipo equivocado no es un error —devuelve cero
    resultados, que es una respuesta válida—, así que el desajuste solo
    se ve confrontando los dos lados.
    """
    tipo = _tipo_que_pide_el_portal()
    r = documentos.get(f"/api/v1/documentos?tipo={tipo}&tamano=50",
                       headers=cab(token_especialista))
    assert r.status_code == 200, (
        f"El portal consulta con tipo={tipo} y el servicio no lo acepta.\n"
        + r.get_data(as_text=True))

    ids = [d["documento_id"] for d in r.get_json()["documentos"]]
    assert evidencia_cargada["documento_id"] in ids, (
        f"El portal pide tipo={tipo}, pero la evidencia se guarda con otro "
        f"tipo. El filtro del servicio la descarta antes de que el portal "
        f"pueda verla.")


def test_la_clave_de_la_lista_es_la_que_el_portal_lee(
        documentos, token_especialista, evidencia_cargada):
    """El sobre de paginación y el lector tienen que usar la misma clave.

    `sobre_pagina` acepta un parámetro `clave`, y este endpoint pasa
    `documentos` en lugar del `elementos` por omisión. Un lector que
    asuma el valor por omisión recibe una lista vacía sin ningún error:
    `.get("elementos", [])` no se queja, devuelve [].
    """
    r = documentos.get("/api/v1/documentos?tipo=EVIDENCIA_ARCHIVO",
                       headers=cab(token_especialista))
    assert r.status_code == 200, r.get_data(as_text=True)

    presentes = {k for k in ("documentos", "elementos") if k in r.get_json()}
    leidas = _claves_que_lee_el_portal()
    assert presentes & leidas, (
        f"El servicio devuelve la lista bajo {sorted(presentes)} y el "
        f"portal lee {sorted(leidas)}. No coinciden, y el desajuste no "
        f"levanta ningun error: la pantalla sale vacia.")


def test_todo_perfil_que_puede_cargar_evidencia_puede_listarla(filas_sql):
    """Poder escribir algo que no se puede volver a leer es una trampa.

    Hoy se cumple: el único perfil que carga evidencias —«Especialista de
    bienestar»— tiene también AGREGADO_GLOBAL e INSTRUMENTO_ADMIN. Pero
    se cumple por coincidencia, no porque nada lo garantice, y los dos
    conjuntos de permisos se declaran en servicios distintos.

    Si alguien añade un perfil de seguimiento sin permisos de consulta, la
    pantalla volvería a decir «no hay evidencias» cuando lo cierto es «no
    puedes verlas». Esta prueba falla antes, y dice cuál es el perfil.
    """
    perfiles = filas_sql(
        "SELECT p.nombre, "
        "       bool_or(pm.codigo = ANY(%s)) AS carga, "
        "       bool_or(pm.codigo = ANY(%s)) AS lista "
        "  FROM usuarios.perfil p "
        "  JOIN usuarios.perfil_permiso pp USING (perfil_id) "
        "  JOIN usuarios.permiso pm USING (permiso_id) "
        " GROUP BY p.nombre",
        (list(PERMISOS_DE_CARGA), list(PERMISOS_DE_LISTADO)))
    assert perfiles, "No se leyeron los perfiles; la prueba no comprobo nada."

    ciegos = [p["nombre"] for p in perfiles if p["carga"] and not p["lista"]]
    assert not ciegos, (
        f"Estos perfiles pueden CARGAR una evidencia y no pueden LISTARLA: "
        f"{ciegos}. El portal recibiria un 403 del listado y lo mostraria "
        f"como 'No hay evidencias registradas todavia', que afirma que el "
        f"trabajo no existe en lugar de decir que no se puede ver.")
