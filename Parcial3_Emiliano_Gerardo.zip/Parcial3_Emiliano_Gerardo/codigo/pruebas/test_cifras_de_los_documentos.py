"""
Las cifras que los documentos afirman tienen que ser ciertas.

POR QUÉ ESTE ARCHIVO EXISTE
---------------------------
Los documentos de la entrega dicen cuántas pruebas hay y cuántos casos
tiene cada archivo. Esas cifras se escribieron a mano y se quedaron viejas
**cuatro veces** en este parcial: el total pasó de 585 a 618 agregando
pruebas, y tres documentos siguieron diciendo 610 y 602.

Es el mismo error que ya había costado una corrida del banco de
rendimiento, donde `reltuples` decía 5 para una tabla con 8 299 filas: una
cifra que alguien escribió cuando era verdad y que nadie volvió a mirar.

Y en un documento de entrega pesa más que en un informe interno. Quien lo
evalúa no puede distinguir «esta cifra se quedó vieja» de «estas cifras
están inventadas», y la segunda lectura contamina todo lo demás que el
documento afirma.

Así que las cifras se comprueban contra la realidad, igual que todo lo
demás.
"""
import pathlib
import re
import subprocess
import sys

import pytest

RAIZ = pathlib.Path(__file__).resolve().parents[1]
DOCS = list((RAIZ / "docs").glob("*.md")) + list(
    (RAIZ / "docs" / "expediente").glob("*.md"))


def _cuantas_pruebas(ruta_relativa):
    """Cuenta los casos que pytest recolecta de un archivo."""
    r = subprocess.run(
        [sys.executable, "-m", "pytest", str(RAIZ / ruta_relativa),
         "-q", "-p", "no:randomly", "--collect-only"],
        capture_output=True, text=True, cwd=RAIZ, timeout=180)
    hallado = re.search(r"(\d+) tests? collected", r.stdout)
    return int(hallado.group(1)) if hallado else None


def test_el_total_que_declaran_los_documentos_es_el_real():
    """«618 pruebas, 616 pasan» tiene que ser verdad hoy."""
    total = _cuantas_pruebas("pruebas")
    assert total, "No se pudo contar las pruebas."

    declarados = set()
    for doc in DOCS:
        for n in re.findall(r"(\d{3}) pruebas", doc.read_text()):
            # 293 es una cifra historica —las pruebas que pasaron a error
            # por el DSN sin comillas— y no una declaracion del total.
            if n != "293":
                declarados.add((doc.name, int(n)))

    malos = [(d, n) for d, n in declarados if n != total]
    assert not malos, (
        f"Hay {total} pruebas y estos documentos dicen otra cosa: "
        f"{malos}. Una cifra vieja en un documento de entrega no se "
        f"distingue de una inventada.")


@pytest.mark.parametrize("archivo", [
    "pruebas/test_analitica.py",
    "pruebas/test_monitoreo.py",
    "pruebas/test_sonda_de_salud.py",
    "pruebas/test_indices_mongo.py",
    "pruebas/test_procesos_integrales.py",
    "pruebas/test_procesos_desde_el_cliente.py",
])
def test_los_casos_que_se_citan_por_archivo_son_los_reales(archivo):
    """Cuando un documento dice «X casos» junto a un archivo, que sean X."""
    reales = _cuantas_pruebas(archivo)
    assert reales, f"No se pudo contar {archivo}."
    nombre = pathlib.Path(archivo).name

    problemas = []
    for doc in DOCS:
        texto = doc.read_text()
        # «test_monitoreo.py` (33 casos)» o «test_monitoreo.py`, 33 casos»
        for cita in re.finditer(
                re.escape(nombre) + r"`?[^\n]{0,20}?(\d{1,3}) casos", texto):
            if int(cita.group(1)) != reales:
                problemas.append((doc.name, int(cita.group(1))))

    assert not problemas, (
        f"{nombre} tiene {reales} casos y se cita con otro numero en: "
        f"{problemas}")
