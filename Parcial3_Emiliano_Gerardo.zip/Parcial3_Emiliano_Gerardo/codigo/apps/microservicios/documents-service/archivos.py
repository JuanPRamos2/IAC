"""
Validación, almacenamiento y recuperación de archivos de evidencia.

POR QUÉ ESTE MÓDULO SE MUDÓ AQUÍ
--------------------------------
Esta lógica existía y funcionaba, pero vivía en el portal web
(`apps/web/app/rutas/evidencias.py`). El efecto era que documents-service
—el servicio cuya responsabilidad declarada es «carga, almacenamiento,
consulta y administración segura de documentos y evidencias; validación de
formatos y tamaños; protección de archivos y recuperación controlada»— solo
guardaba metadatos, y la parte difícil la hacía otro componente.

Dos consecuencias concretas, no estéticas:

1. **Solo el portal podía subir evidencia.** La aplicación de escritorio y
   la móvil hablan con los microservicios, no con el portal. Para ellas la
   carga de evidencia sencillamente no existía.

2. **La validación no era una propiedad del sistema, sino de una pantalla.**
   Cualquier cliente que llamara a `POST /api/v1/documentos` directamente
   registraba un documento sin pasar por la comprobación de firma ni por el
   límite de tamaño, porque esas comprobaciones estaban del otro lado.

Ahora la validación está en el servicio. El portal pasa a ser un cliente
más, y lo que antes era una regla de una pantalla es una regla del sistema.

DÓNDE QUEDA CADA COSA
---------------------
El archivo va al almacén de blobs —una carpeta en developer, el punto de
montaje de un bucket en production— y los metadatos a MongoDB. La
separación se mantiene a propósito: MongoDB no es un almacén de archivos, y
guardar un PDF de 8 MB como documento volvería lenta cualquier consulta de
la colección.

CUATRO DECISIONES QUE NO SE VEN EN LA RESPUESTA
-----------------------------------------------
1. **El nombre que manda el cliente NO se usa como ruta.** Un nombre como
   `../../etc/passwd` escribiría fuera de la carpeta. El archivo se guarda
   bajo el SHA-256 de su contenido y el nombre original queda solo como
   metadato que se muestra.

2. **El tipo se decide por el contenido, no por la extensión.** Un
   ejecutable renombrado a `.pdf` pasa cualquier validación de extensión;
   no pasa la de firma.

3. **El hash es la identidad.** Subir dos veces el mismo archivo no lo
   duplica: se reconoce y se reutiliza. Ese mismo hash permite después
   comprobar que lo que alguien descargó es lo que se subió.

4. **El tamaño se revisa ANTES de leer el archivo completo en memoria.** Al
   revés, un archivo de 2 GB se cargaría entero para después rechazarlo, y
   bastarían unas pocas peticiones así para tumbar el servicio.
"""
import hashlib
import os
import re
import unicodedata

from comun import ErrorApi

# 8 MB. Un acta, una minuta o una foto de una sesión caben de sobra; un
# video no, y no es lo que una evidencia de intervención debe ser.
TAMANO_MAXIMO = int(os.environ.get("EVIDENCIA_TAMANO_MAXIMO", str(8 * 1024 * 1024)))

# Firma real de cada formato admitido.
FIRMAS = {
    "pdf": [b"%PDF-"],
    "png": [b"\x89PNG\r\n\x1a\n"],
    "jpg": [b"\xff\xd8\xff"],
    # Office moderno es un ZIP: la firma es la del contenedor.
    "docx": [b"PK\x03\x04", b"PK\x05\x06"],
    "xlsx": [b"PK\x03\x04", b"PK\x05\x06"],
    # Texto plano y CSV no tienen firma; se valida que sea decodificable.
    "txt": [],
    "csv": [],
}

TIPOS_MIME = {
    "pdf": "application/pdf",
    "png": "image/png",
    "jpg": "image/jpeg",
    "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "txt": "text/plain; charset=utf-8",
    "csv": "text/csv; charset=utf-8",
}


def almacen():
    """Carpeta del almacén, leída en cada operación.

    Leerla en cada operación y no al importar el módulo permite que un
    envoltorio de arranque la defina después de cargar los módulos, que es
    lo que hacen varios servidores de aplicación. Con una constante de
    módulo, definir la variable después de importar no tiene efecto y no
    hay manera de notarlo.
    """
    return os.environ.get("ALMACEN_EVIDENCIAS", "/var/lib/bienestar/evidencias")


def extension_de(nombre):
    nombre = nombre or ""
    return nombre.rsplit(".", 1)[-1].lower() if "." in nombre else ""


def nombre_presentable(nombre):
    """Limpia el nombre para MOSTRARLO. Nunca se usa como ruta."""
    nombre = unicodedata.normalize("NFKD", nombre or "")
    nombre = nombre.encode("ascii", "ignore").decode("ascii")
    nombre = re.sub(r"[^A-Za-z0-9._ -]", "_", nombre).strip()
    # Las secuencias de puntos se colapsan: el nombre nunca se usa como
    # ruta, pero uno que se muestre como "..__..__tmp_acta.pdf" solo
    # confunde a quien lo lee en la tabla.
    nombre = re.sub(r"\.{2,}", ".", nombre).lstrip("._-")
    return (nombre or "sin_nombre")[:120]


def firma_coincide(contenido, extension):
    firmas = FIRMAS.get(extension)
    if firmas is None:
        return False
    if not firmas:                        # txt y csv: tiene que ser texto
        try:
            contenido[:4096].decode("utf-8")
            return True
        except UnicodeDecodeError:
            return False
    return any(contenido.startswith(f) for f in firmas)


def ruta_relativa(sha256):
    """Dos niveles de subcarpeta por los primeros caracteres del hash.

    Un directorio plano con decenas de miles de archivos se vuelve lento de
    listar en casi cualquier sistema de archivos.

    ESTA FUNCIÓN ES LA ÚNICA QUE DECIDE DÓNDE VIVE UN ARCHIVO, y existe
    para que lo sea. Antes el reparto estaba escrito dos veces: una en
    `ruta_de`, para el disco, y otra dentro de `url_firmada`, para armar
    el nombre del objeto en Cloud Storage. Las dos coincidían, y
    coincidían por casualidad: nada lo comprobaba.

    Lo que eso costaba el día que alguien cambiara una: en developer todo
    seguiría funcionando, porque la descarga va por el servicio y usa
    `ruta_de`. En la máquina de Google, donde el almacén es el punto de
    montaje del bucket, las direcciones firmadas apuntarían a objetos que
    no existen y las descargas darían 404 sin que nada en el código
    pareciera roto. Un fallo que solo aparece en el ambiente donde no se
    puede depurar.

    El objeto del bucket y la ruta en disco son el MISMO camino relativo,
    y ahora de verdad: el montaje hace que escribir en
    `almacen()/ab/cd/abcd...` cree el objeto `ab/cd/abcd...`.
    """
    return os.path.join(sha256[:2], sha256[2:4], sha256)


def ruta_de(sha256):
    """La ruta en disco. El almacén más el camino relativo, nada más."""
    return os.path.join(almacen(), ruta_relativa(sha256))


def validar(contenido, nombre_original):
    """Valida formato y tamaño. Devuelve (extension, sha256, nombre).

    Lanza ErrorApi con el detalle de QUÉ falló: un «archivo inválido» a
    secas obliga a quien lo recibe a adivinar si el problema es el formato,
    el tamaño o el contenido.
    """
    problemas = []

    if not contenido:
        problemas.append({"campo": "archivo", "problema": "esta vacio"})
    elif len(contenido) > TAMANO_MAXIMO:
        problemas.append({
            "campo": "archivo",
            "problema": f"pesa {len(contenido)} bytes y el maximo son "
                        f"{TAMANO_MAXIMO} ({TAMANO_MAXIMO // 1024 // 1024} MB)"})

    extension = extension_de(nombre_original)
    if extension not in FIRMAS:
        problemas.append({
            "campo": "nombre_archivo",
            "problema": f"formato '{extension or 'sin extension'}' no admitido; "
                        f"validos: {', '.join(sorted(FIRMAS))}"})
    elif contenido and not firma_coincide(contenido, extension):
        # El caso que una validación por extensión deja pasar.
        problemas.append({
            "campo": "archivo",
            "problema": f"el contenido no corresponde a un archivo {extension}; "
                        f"la extension dice una cosa y los primeros bytes otra"})

    if problemas:
        raise ErrorApi("ARCHIVO_INVALIDO",
                       "El archivo no cumple las reglas de formato o tamano.",
                       422, problemas)

    return extension, hashlib.sha256(contenido).hexdigest(), \
        nombre_presentable(nombre_original)


def guardar(contenido, sha256):
    """Escribe el blob. Devuelve True si era nuevo, False si ya estaba.

    La escritura es a un archivo temporal y después un `rename`, que es
    atómico dentro del mismo sistema de archivos. Escribir directo sobre la
    ruta final dejaría, si el proceso muere a la mitad, un archivo con el
    nombre correcto y el contenido truncado: exactamente el caso que el
    hash ya no podría detectar, porque nadie lo volvería a calcular.
    """
    ruta = ruta_de(sha256)
    if os.path.exists(ruta):
        return False
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    temporal = f"{ruta}.parcial"
    with open(temporal, "wb") as f:
        f.write(contenido)
    os.replace(temporal, ruta)
    return True


def url_firmada(sha256, minutos=10):
    """URL temporal de Cloud Storage, o None si este ambiente no firma.

    En developer el archivo se descarga por el propio servicio. En la
    máquina de Google, GCS_BUCKET y la llave de la cuenta de servicio
    permiten entregar el archivo sin abrirlo al mundo: la dirección deja
    de servir cuando vence.

    SE COMPRUEBA QUE EL OBJETO EXISTA ANTES DE FIRMAR
    -------------------------------------------------
    Firmar es una operación local: la biblioteca arma la dirección con la
    llave y no pregunta nada a Google. Así que una dirección firmada para
    un objeto que no está se entrega igual, con cara de válida, y el
    cliente se encuentra un 404 de Cloud Storage —un XML, no el error del
    sistema— sin ninguna pista de por qué.

    Cuesta una llamada y convierte ese 404 silencioso en un error del
    sistema que dice qué pasó: el registro del documento existe y su
    archivo no llegó al bucket.
    """
    bucket = os.environ.get("GCS_BUCKET", "").strip()
    llave = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS", "").strip()
    if not bucket or not llave or not os.path.isfile(llave):
        return None
    from datetime import timedelta
    from google.cloud import storage
    cliente = storage.Client.from_service_account_json(llave)
    # `ruta_relativa` y no un camino armado aquí: ver su comentario.
    blob = cliente.bucket(bucket).blob(ruta_relativa(sha256))
    if not blob.exists():
        raise ErrorApi(
            "ARCHIVO_NO_ESTA_EN_EL_BUCKET",
            "El documento esta registrado pero su archivo no esta en Cloud "
            "Storage. No se entrega una direccion firmada que daria un 404 "
            "de Google sin explicacion.", 409,
            [{"campo": "objeto", "problema": ruta_relativa(sha256)}])
    return blob.generate_signed_url(
        version="v4", expiration=timedelta(minutes=minutos), method="GET")


def leer(sha256):
    """Devuelve el contenido, o lanza si no está o si fue alterado."""
    ruta = ruta_de(sha256)
    if not os.path.exists(ruta):
        raise ErrorApi("ARCHIVO_NO_ENCONTRADO",
                       "El registro del documento existe pero su archivo no "
                       "esta en el almacen.", 404,
                       [{"campo": "sha256", "problema": sha256}])
    with open(ruta, "rb") as f:
        contenido = f.read()

    # Se recalcula el hash al leer. Cuesta milisegundos y es la única forma
    # de notar que el archivo cambió en el almacén después de guardarse:
    # sin esto, una evidencia alterada se entregaría como legítima, que es
    # justo lo que un sello sirve para impedir.
    real = hashlib.sha256(contenido).hexdigest()
    if real != sha256:
        raise ErrorApi("ARCHIVO_ALTERADO",
                       "El archivo almacenado no coincide con su sello. No se "
                       "entrega: una evidencia que cambio despues de "
                       "registrarse ya no respalda nada.", 409,
                       [{"campo": "sello_registrado", "problema": sha256},
                        {"campo": "sello_real", "problema": real}])
    return contenido


# ---------------------------------------------------------------------------
# Estado del almacén para la sonda de salud
# ---------------------------------------------------------------------------
#
# POR QUÉ EL BUCKET TIENE QUE APARECER EN LA SONDA
# ------------------------------------------------
# Las sondas comprobaban PostgreSQL, MongoDB y Redis. Con eso, un
# documents-service cuyo almacén de archivos está caído contesta «listo» y
# 200: PostgreSQL responde, MongoDB responde, Redis responde. El servicio
# acepta cargas, valida el archivo, calcula su hash, escribe los metadatos
# en MongoDB... y falla al escribir el blob, con el registro ya creado.
#
# Ése es el peor de los dos fallos posibles: un documento registrado cuyo
# archivo no existe. El registro dice que la evidencia está, la descarga
# da 404, y la bitácora muestra una carga exitosa. Que la sonda lo vea
# antes no evita el fallo, pero sí lo hace visible donde se mira.
#
# POR QUÉ ES OPCIONAL Y NO ESENCIAL
# ---------------------------------
# Sacar el servicio de rotación —503— sería peor que dejarlo degradado.
# Con el almacén caído el servicio todavía sirve toda la consulta de
# metadatos: listar documentos de una campaña, buscar por hash, ver quién
# subió qué y cuándo. Eso es la mayoría del tráfico. Un 503 apagaría esas
# pantallas por una falla que solo afecta a la carga y la descarga.
#
# Así que: `degradado`, 200, y `degradado_por: ["almacen"]`. Quien opera lo
# ve; quien consulta metadatos sigue trabajando; quien intenta subir recibe
# el error del almacén, que es la verdad.
#
# QUÉ SE COMPRUEBA, Y POR QUÉ ASÍ
# -------------------------------
# `os.path.isdir` no basta. En production el almacén es el punto de montaje
# del bucket, y un montaje muerto deja el directorio *visible* pero
# cualquier operación real sobre él devuelve EIO. `statvfs` es una llamada
# al sistema de archivos de verdad: con el montaje caído lanza, con el
# directorio sano contesta. Esa es la diferencia entre comprobar que el
# nombre existe y comprobar que el almacén responde.
#
# Y se comprueba que se pueda ESCRIBIR, no solo leer. Un bucket montado de
# solo lectura —porque la cuenta de servicio perdió el permiso, que es la
# falla de permisos más común en GCS— pasa cualquier comprobación de
# lectura y falla en cada carga.

# El bucket se consulta a lo más una vez cada este número de segundos. Una
# llamada a Cloud Storage es una ida y vuelta por red, y la sonda la
# contestan el orquestador y el panel central varias veces por minuto: sin
# este techo, la comprobación de salud cuesta más que el trabajo.
RECUERDO_BUCKET_S = float(os.environ.get("ALMACEN_RECUERDO_BUCKET", "30"))
_bucket_visto = {"cuando": 0.0, "error": None}


def _comprobar_bucket_remoto(bucket, llave):
    """Pregunta a Cloud Storage si el bucket está, a lo más cada 30 s."""
    import time
    ahora = time.time()
    if ahora - _bucket_visto["cuando"] < RECUERDO_BUCKET_S:
        if _bucket_visto["error"]:
            raise RuntimeError(_bucket_visto["error"])
        return
    try:
        from google.cloud import storage
        cliente = storage.Client.from_service_account_json(llave)
        if not cliente.bucket(bucket).exists():
            raise RuntimeError(f"el bucket {bucket} no existe o no es visible "
                               "para esta cuenta de servicio")
    except Exception as exc:
        _bucket_visto["cuando"] = ahora
        _bucket_visto["error"] = str(exc)
        raise
    _bucket_visto["cuando"] = ahora
    _bucket_visto["error"] = None


def ping_almacen():
    """Comprueba el almacén de evidencias. Lanza si no sirve para trabajar.

    Dos partes, porque son dos fallas distintas:

    1. El almacén local —carpeta en developer, montaje del bucket en
       production—: que exista, que responda y que se pueda escribir.
    2. El bucket de Cloud Storage, solo si está configurado: que siga ahí
       y que la cuenta de servicio lo vea. Sin esto, la firma de URLs
       —que es una operación local— seguiría «funcionando» y entregando
       direcciones hacia un bucket que ya no está.
    """
    carpeta = almacen()
    if not os.path.isdir(carpeta):
        raise RuntimeError(f"el almacen {carpeta} no existe o no es un directorio")
    # Llamada real al sistema de archivos: un montaje muerto falla aquí y
    # no en `isdir`.
    os.statvfs(carpeta)
    if not os.access(carpeta, os.W_OK | os.X_OK):
        raise RuntimeError(f"el almacen {carpeta} no admite escritura")

    bucket = os.environ.get("GCS_BUCKET", "").strip()
    llave = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS", "").strip()
    if bucket and llave and os.path.isfile(llave):
        _comprobar_bucket_remoto(bucket, llave)
