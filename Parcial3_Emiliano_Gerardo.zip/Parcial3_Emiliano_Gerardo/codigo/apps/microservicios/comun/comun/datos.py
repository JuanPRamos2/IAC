"""Acceso a PostgreSQL. Las consultas siempre van parametrizadas."""
import contextlib
import os

import psycopg2
import psycopg2.extras
from psycopg2 import pool

_pool = None


# Tiempo máximo de UNA sentencia en PostgreSQL.
#
# POR QUÉ ESTO EXISTE, Y POR QUÉ NO BASTA EL TIEMPO DE ESPERA DE GUNICORN
# ----------------------------------------------------------------------
# Antes no había ningún límite por consulta. El único tope era el de
# gunicorn, que ante una petición que no termina mata al obrero. Eso tiene
# tres consecuencias, y las tres son malas:
#
# 1. **El cliente no recibe un error, recibe una conexión cortada.** No
#    hay código, no hay mensaje, no hay identificador de correlación: la
#    aplicación móvil o de escritorio ve «la conexión se cerró» y no puede
#    distinguirlo de un corte de red ni decirle nada útil a quien la usa.
#
# 2. **La consulta sigue corriendo.** Matar al obrero no cancela nada en
#    PostgreSQL: el servidor sigue ejecutando una consulta cuyo resultado
#    ya no tiene a quién entregarle, ocupando CPU y memoria. Y la petición
#    que se reintenta arranca otra igual. Tres reintentos son tres
#    consultas vivas haciendo el mismo trabajo inútil.
#
# 3. **Se cae todo lo que ese obrero tenía en vuelo.** Con `-w 2
#    --threads 2`, matar un obrero tira hasta dos peticiones sanas que
#    compartían el proceso con la lenta.
#
# `statement_timeout` lo resuelve donde está el problema: PostgreSQL
# cancela SU consulta, devuelve un error, y la conexión queda usable. El
# servicio traduce ese error a un 503 con código y explicación —ver
# `registrar_manejadores`—. El tope de gunicorn sigue ahí como última red,
# y se configura MÁS ALTO que éste a propósito, para que el que actúe
# primero sea el que puede contestar.
TIEMPO_MAXIMO_CONSULTA_MS = int(os.environ.get("PG_TIEMPO_MAXIMO_MS", "15000"))


def _dsn():
    # `options` viaja en la cadena de conexión y PostgreSQL lo aplica a la
    # sesión entera, así que vale para toda consulta que salga de este
    # pool sin que cada llamada tenga que acordarse de ponerlo.
    #
    # LAS COMILLAS SIMPLES NO SON ADORNO. El formato clave=valor de libpq
    # separa opciones por espacios, y el valor de `options` contiene uno.
    # Sin comillas, libpq lee `statement_timeout=15000` como una opción de
    # conexión aparte y falla con «invalid connection option». Ese error
    # dejó 293 pruebas en error de golpe, porque el pool no se podía crear.
    return (f"host={os.environ.get('PG_HOST','datos')} "
            f"port={os.environ.get('PG_PUERTO','5432')} "
            f"dbname={os.environ.get('PG_BASE','bienestar')} "
            f"user={os.environ.get('PG_USUARIO','bienestar_app')} "
            f"password={os.environ.get('PG_CLAVE','')} "
            f"options='-c statement_timeout={TIEMPO_MAXIMO_CONSULTA_MS}' "
            f"application_name={os.environ.get('NOMBRE_SERVICIO','microservicio')}")


def obtener_pool():
    global _pool
    if _pool is None:
        _pool = pool.ThreadedConnectionPool(1, int(os.environ.get("PG_POOL_MAX", "5")), _dsn())
    return _pool


@contextlib.contextmanager
def cursor(commit: bool = False):
    p = obtener_pool()
    cn = p.getconn()
    try:
        with cn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            yield cur
        cn.commit() if commit else cn.rollback()
    except Exception:
        cn.rollback()
        raise
    finally:
        p.putconn(cn)


def consultar(sql, params=None):
    with cursor() as cur:
        cur.execute(sql, params or ())
        return cur.fetchall()


def consultar_uno(sql, params=None):
    with cursor() as cur:
        cur.execute(sql, params or ())
        return cur.fetchone()


def ping():
    with cursor() as cur:
        cur.execute("SELECT 1")
        cur.fetchone()
