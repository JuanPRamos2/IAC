"""
Fábrica común de microservicios.

Todo servicio del proyecto obtiene de aquí, sin volver a escribirlo:

  - identificador de correlación por petición, que viaja en la respuesta
    y en la bitácora, para poder seguir una operación que atraviesa varios
    servicios;
  - registro de actividad de cada petición;
  - los tres endpoints de salud que pide la rúbrica;
  - manejo estandarizado de errores;
  - respuesta en JSON o XML según el encabezado Accept;
  - límite de consumo por token, apoyado en Redis.

Lo que NO está aquí es la lógica de negocio: cada servicio tiene una sola
responsabilidad y la implementa en su propio archivo.
"""
import datetime
import logging
import os
import threading
import time
import uuid

from flask import Flask, Response, g, jsonify, request

from .errores import ErrorApi, quiere_xml, registrar_manejadores
from .xmlizar import a_xml

VERSION_API = "v1"

# La identidad de este proceso. Se calcula una vez, al importar el módulo,
# y es lo que permite a monitoring-service distinguir «el servicio sigue
# arriba» de «el servicio se reinició y ahora está arriba otra vez». Las
# dos cosas se ven idénticas desde una sonda de vida sin esto.
# Memoria de corta duración para los FALLOS de dependencias opcionales.
#
# EL PROBLEMA QUE RESUELVE, MEDIDO
# --------------------------------
# `/health/ready` comprueba cada dependencia en serie. Una dependencia
# caída no responde: se espera su tiempo de espera completo. Con MongoDB
# abajo —que para algorithms-service es OPCIONAL— el cliente de pymongo
# espera 1.2 s, y se midió: la sonda de algorithms-service tardaba
# **1286 ms**, y el panel de monitoreo, que sondea a los veinticuatro
# componentes en paralelo, tardaba 1.6 s por culpa de los cuatro
# servicios que esperan a MongoDB.
#
# Eso anula el sentido de haber declarado la dependencia opcional. Un
# orquestador con un tiempo de espera de sonda de un segundo —lo normal—
# declara muerto a un servicio que está atendiendo correctamente, y
# justamente por preguntar si algo que no necesita está disponible.
#
# SOLO SE RECUERDAN LOS FALLOS, Y SOLO DE LAS OPCIONALES
# ------------------------------------------------------
# Los éxitos no se recuerdan porque no hacen falta: una comprobación que
# funciona cuesta medio milisegundo. Lo que cuesta es el fallo, porque un
# fallo ES una espera agotada. Recordando solo los fallos, la sonda nunca
# es lenta y la RECUPERACIÓN se detecta en la primera sonda después de
# que caduque el recuerdo.
#
# Las esenciales NO se recuerdan nunca, y es la decisión que importa: el
# trabajo de una sonda de listo es decirle al orquestador si mandar
# tráfico AHORA. Un «listo» viejo sobre una dependencia esencial manda
# tráfico a un servicio roto. Un «degradado» viejo sobre una opcional
# atrasa un tablero unos segundos.
RECUERDO_FALLO_OPCIONAL_S = float(
    os.environ.get("SALUD_RECUERDO_FALLO", "15"))
_fallos_opcionales = {}
_candado_fallos = threading.Lock()

# Y UN PRESUPUESTO DE TIEMPO PROPIO PARA LAS OPCIONALES
# -----------------------------------------------------
# El recuerdo de arriba arregla catorce de cada quince sondas, pero la que
# cae justo al caducar sigue pagando el tiempo de espera completo —1.2 s
# con MongoDB abajo— y un orquestador que sondea con un segundo de
# paciencia saca el servicio de rotación precisamente en esa.
#
# Así que una comprobación OPCIONAL se corre con su propio presupuesto, y
# si no contesta en ese plazo se da por caída sin esperarla más. La
# llamada de abajo sigue su curso en su hilo y muere cuando le toque: no
# se espera, que es lo único que importa aquí.
#
# 300 ms es generoso para decir «está ahí»: una dependencia local que no
# contesta en 300 ms no está disponible a efectos prácticos, y el precio
# de equivocarse es un «degradado» de más en un servicio que de todas
# formas puede atender sin ella. El precio de NO ponerlo es un servicio
# sano sacado de rotación.
#
# Solo se aplica a las opcionales. Una esencial se espera lo que haga
# falta: su resultado decide si mandar tráfico, y ahí vale más la
# respuesta correcta que la rápida.
PRESUPUESTO_OPCIONAL_S = float(
    os.environ.get("SALUD_PRESUPUESTO_OPCIONAL", "0.3"))

# Y UN PRESUPUESTO MÁS CORTO PARA EL «¿YA VOLVIÓ?»
# ------------------------------------------------
# Con solo el recuerdo de arriba había que elegir entre dos cosas malas:
# reintentar en cada sonda —y pagar el presupuesto completo cada vez,
# porque la dependencia sigue caída, que es justo lo que el recuerdo
# venía a evitar— o no reintentar hasta que caduque, y entonces una
# dependencia que vuelve sigue anunciándose caída quince segundos.
#
# La prueba `test_la_recuperacion_de_una_opcional_se_detecta_de_inmediato`
# falló contra la segunda opción, y con razón: quien opera estaría
# mirando una falla que ya no existe.
#
# No hace falta elegir. Cuando HAY un fallo recordado, la pregunta que se
# hace es más fácil que la original: no «¿funciona?» sino «¿ya volvió?».
# Y eso se contesta rápido o no se contesta: una dependencia local que
# está viva responde a un ping en menos de un milisegundo. Cincuenta
# milisegundos son de sobra para distinguir «volvió» de «sigue caída», y
# si sigue caída se pierden 50 ms en lugar de 300.
#
# Resultado: la recuperación se detecta en la sonda siguiente y el peor
# caso de una sonda con la dependencia caída es 50 ms.
PRESUPUESTO_REINTENTO_S = float(
    os.environ.get("SALUD_PRESUPUESTO_REINTENTO", "0.05"))


class _TiempoAgotado(Exception):
    pass


def _con_presupuesto(fn, segundos, al_terminar_tarde=None):
    """Corre fn y se rinde a los `segundos`, sin esperar a que termine.

    DEJAR DE ESPERAR NO ES DEJAR DE APRENDER
    ----------------------------------------
    Si la comprobación tarda más que el presupuesto, lo único que se sabe
    es «no contestó», y eso no sirve para arreglar nada: no distingue un
    nombre de host que no resuelve de una conexión rechazada o de unas
    credenciales mal puestas. La causa la trae el error del cliente, que
    llega tarde.

    Así que el hilo sigue su curso y, cuando termina, deja su resultado
    en `al_terminar_tarde`. La sonda que ya contestó no cambia, pero la
    SIGUIENTE reporta la causa de verdad. Se dejó de esperar sin dejar de
    averiguar, que era el objetivo: lo que no se podía permitir era la
    espera, no el diagnóstico.
    """
    caja = {}
    listo = threading.Event()

    def correr():
        try:
            fn()
            caja["ok"] = True
        except BaseException as e:                       # noqa: BLE001
            caja["error"] = e
        finally:
            # `listo` se pone cuando la sonda DEJO de esperar. Si ya esta
            # puesto cuando este hilo termina, este hilo llego tarde: su
            # resultado no sirve para la respuesta que ya se envio, pero
            # si para la siguiente.
            if listo.is_set() and al_terminar_tarde is not None:
                al_terminar_tarde(caja.get("error"))

    hilo = threading.Thread(target=correr, daemon=True)
    hilo.start()
    hilo.join(segundos)
    listo.set()
    if "ok" in caja:
        return
    if "error" in caja:
        raise caja["error"]
    raise _TiempoAgotado(
        f"no contesto en {segundos:.2f} s; se da por caida sin esperar mas "
        f"porque es una dependencia opcional y el servicio puede atender "
        f"sin ella")


_INICIO = time.time()
INSTANCIA = uuid.uuid4().hex[:12]
ARRANCADO_EN = datetime.datetime.fromtimestamp(
    _INICIO, datetime.timezone.utc).isoformat()


def responder(datos: dict, http: int = 200, raiz: str = "respuesta"):
    """Devuelve el mismo contenido en JSON o en XML, según lo pedido.

    Siempre se devuelve un objeto Response, no la tupla (cuerpo, codigo).
    La diferencia importa porque un endpoint que necesita agregar una
    cabecera —X-Cache en queries-service, X-Reporte-Sello en
    reports-service— puede hacerlo sobre lo que esta funcion devuelve, en
    lugar de tener que rearmar la respuesta a mano y arriesgarse a que la
    version XML y la JSON salgan distintas.
    """
    if quiere_xml():
        return Response(a_xml(datos, raiz=raiz), status=http,
                        mimetype="application/xml")
    respuesta = jsonify(datos)
    respuesta.status_code = http
    return respuesta


def pagina():
    """Lee y valida los parámetros de paginación.

    El tope de 100 por página no es decorativo: sin él, un cliente podría
    pedir un millón de registros y tumbar el servicio con una sola
    petición.
    """
    try:
        p = int(request.args.get("pagina", 1))
        t = int(request.args.get("tamano", 20))
    except ValueError:
        raise ErrorApi("PARAMETRO_INVALIDO",
                       "Los parametros 'pagina' y 'tamano' deben ser enteros.", 400)
    if p < 1:
        raise ErrorApi("PARAMETRO_INVALIDO", "'pagina' empieza en 1.", 400)
    if not 1 <= t <= 100:
        raise ErrorApi("PARAMETRO_INVALIDO",
                       "'tamano' debe estar entre 1 y 100.", 400)
    return p, t


def sobre_pagina(elementos, total, p, t, clave="elementos"):
    """Sobre de paginación común a todos los listados."""
    total_paginas = max(1, (total + t - 1) // t)
    return {
        clave: elementos,
        "paginacion": {
            "pagina": p, "tamano": t, "total": total,
            "total_paginas": total_paginas,
            "tiene_siguiente": p < total_paginas,
            "tiene_anterior": p > 1,
        },
    }


def limite_consumo(maximo: int = 120, ventana: int = 60):
    """Límite de peticiones por token y minuto, con contador en Redis.

    Si Redis no responde, se deja pasar: el límite protege de un abuso,
    no de un ataque, y perder el límite es preferible a negar servicio a
    todos los clientes legítimos por una caída de la caché.
    """
    from .seguridad import obtener_redis
    try:
        clave_actor = (getattr(g, "actor", {}) or {}).get("jti") or request.remote_addr
        clave = f"limite:{request.blueprint or 'api'}:{clave_actor}"
        r = obtener_redis()
        n = r.incr(clave)
        if n == 1:
            r.expire(clave, ventana)
        if n > maximo:
            # El Retry-After sale del TTL REAL de la clave, no de la ventana
            # declarada: a quien llega al limite en el segundo 55 le quedan
            # 5 segundos, no 60, y decirle 60 lo deja esperando de mas.
            restante = r.ttl(clave)
            if not isinstance(restante, int) or restante < 1:
                restante = ventana
            raise ErrorApi(
                "LIMITE_EXCEDIDO",
                f"Mas de {maximo} peticiones por {ventana} segundos. "
                f"Reintenta en {restante} s.", 429,
                cabeceras={"Retry-After": str(restante)})
    except ErrorApi:
        raise
    except Exception:
        pass


# Las dependencias de infraestructura que el sistema entero puede tener.
#
# POR QUÉ LA SONDA DICE LO QUE *NO* USA
# -------------------------------------
# Cada servicio comprueba las dependencias que tiene, y no las que no
# tiene: pedirle a users-service el estado del bucket no significa nada,
# porque users-service no guarda archivos.
#
# El problema es cómo se lee eso desde fuera. Un panel que recibe
# `dependencias: {postgresql, redis}` de users-service no puede distinguir
# «este servicio no usa MongoDB» de «la comprobación de MongoDB no se
# ejecutó». Las dos se ven igual: la clave no está. Y las dos consecuencias
# son opuestas: la primera es normal, la segunda es un hueco de
# observabilidad —precisamente el hueco que hace que una dependencia caída
# pase inadvertida porque nadie la estaba mirando.
#
# Con `no_aplican` el silencio deja de ser ambiguo: si una dependencia no
# está ni en `dependencias` ni en `no_aplican`, es un error de declaración
# y se nota. El conjunto completo lo decide esta lista, no cada servicio,
# así que agregar una dependencia nueva al sistema la hace aparecer de
# inmediato en las sondas de los veinte servicios.
DEPENDENCIAS_DEL_SISTEMA = frozenset({"postgresql", "mongodb", "redis", "almacen"})


# =========================================================================
# El tiempo máximo de una petición
# =========================================================================
#
# `statement_timeout` (ver `datos.py`) corta una CONSULTA que tarda
# demasiado, y eso cubre la mayoría de los casos porque la mayoría del
# tiempo de una petición es base de datos. Pero no todo:
#
#   - El motor de análisis agrupa y ajusta tendencias en Python puro. Con
#     110 unidades y 12 campañas son miles de operaciones, y ninguna de
#     ellas es una consulta que PostgreSQL pueda cancelar.
#   - Un endpoint que hace cien consultas de 200 ms cada una no excede
#     ningún `statement_timeout` y tarda veinte segundos.
#
# En los dos casos el único tope sería el de gunicorn, que mata al obrero
# sin contestar. Así que la petición lleva su propio plazo, y el trabajo
# largo lo consulta: `exigir_tiempo()` dentro de un bucle convierte «el
# obrero murió» en «503 con código, mensaje y qué hacer».
#
# POR QUÉ ES COOPERATIVO Y NO UNA ALARMA
# --------------------------------------
# Lo natural sería `signal.alarm` o un hilo que interrumpa. Las dos cosas
# están mal aquí: las señales solo llegan al hilo principal y el servicio
# corre con `-k gthread --threads 2`, así que la alarma cortaría una
# petición al azar, no la lenta. Y matar un hilo a la fuerza en Python lo
# deja a medias, posiblemente con una transacción abierta y una conexión
# del pool inutilizable.
#
# Cooperativo significa que el bucle decide dónde es seguro rendirse. Es
# menos automático y es correcto: se rinde entre iteraciones, con la
# transacción en un estado limpio.
#
# Se configura POR DEBAJO del tope de gunicorn a propósito. El orden
# importa: si gunicorn actuara primero, nada de esto se vería nunca y el
# cliente seguiría recibiendo una conexión cortada.
TIEMPO_MAXIMO_PETICION_S = float(os.environ.get("TIEMPO_MAXIMO_PETICION", "20"))


def tiempo_restante():
    """Segundos que le quedan a esta petición. Fuera de una, infinito.

    Infinito y no cero fuera de una petición: este módulo también lo usan
    guiones y pruebas, y devolver cero haría que todo bucle se rindiera en
    la primera iteración.
    """
    plazo = getattr(g, "plazo", None) if g else None
    if plazo is None:
        return float("inf")
    return plazo - time.perf_counter()


def exigir_tiempo(que_falta="la operacion"):
    """Lanza 503 si esta petición ya gastó su plazo. Se llama en bucles largos."""
    restante = tiempo_restante()
    if restante > 0:
        return
    raise ErrorApi(
        "TIEMPO_EXCEDIDO",
        f"La peticion excedio el tiempo maximo de "
        f"{TIEMPO_MAXIMO_PETICION_S:.0f} s mientras calculaba "
        f"{que_falta}, y se detuvo. Se detuvo a proposito y no se perdio "
        f"nada: no se escribio ningun resultado parcial. Acota el alcance "
        f"—una campania, una unidad— o pide el calculo por partes.",
        503, [{"campo": "tiempo_maximo_s", "problema": f"{TIEMPO_MAXIMO_PETICION_S:.0f}"}],
        cabeceras={"Retry-After": "10"})


def crear_servicio(nombre: str, descripcion: str, comprobaciones=None) -> Flask:
    """comprobaciones: dict nombre -> función sin argumentos que lanza si falla."""
    app = Flask(nombre)
    ambiente = os.environ.get("APP_AMBIENTE", "developer")
    logging.basicConfig(
        level=getattr(logging, os.environ.get("NIVEL_BITACORA", "INFO"), logging.INFO),
        format=f"%(asctime)s %(levelname)s [{nombre}/{ambiente}] %(message)s")

    comprobaciones = comprobaciones or {}

    @app.before_request
    def _antes():
        g.inicio = time.perf_counter()
        # El plazo de ESTA petición. Ver `exigir_tiempo`: hay trabajo que
        # no pasa por PostgreSQL y que `statement_timeout` no puede
        # cortar.
        g.plazo = g.inicio + TIEMPO_MAXIMO_PETICION_S
        # Si el cliente ya trae un identificador de correlacion se respeta:
        # asi una operacion que pasa por tres servicios se puede seguir
        # completa en la bitacora con un solo identificador.
        g.correlacion_id = (request.headers.get("X-Correlacion-Id")
                            or uuid.uuid4().hex[:16])

    @app.after_request
    def _despues(resp):
        ms = (time.perf_counter() - getattr(g, "inicio", time.perf_counter())) * 1000
        resp.headers["X-Correlacion-Id"] = getattr(g, "correlacion_id", "")
        resp.headers["X-Servicio"] = nombre
        resp.headers["X-Version-Api"] = VERSION_API
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        if not request.path.startswith("/health"):
            app.logger.info("%s %s -> %s en %.1f ms [corr=%s]",
                            request.method, request.path, resp.status_code, ms,
                            getattr(g, "correlacion_id", ""))
        return resp

    # ------------------------------------------------- endpoints de salud
    @app.get("/health/live")
    def _vivo():
        """La sonda de vida, con la identidad de ESTA instancia.

        POR QUÉ DEVUELVE `instancia` Y `arrancado_en`
        ---------------------------------------------
        Sin esos dos campos, un contenedor que se reinicia en bucle pasa
        TODAS las sondas. Cada petición llega a un proceso recién
        arrancado que contesta «vivo» con toda honestidad, y el reinicio
        —que es el problema— no se ve en ningún lado.

        `instancia` es un identificador nuevo por proceso, así que
        monitoring-service puede comparar el de ahora con el que vio antes
        y contar los reinicios. Se usa el identificador y no solo la hora
        porque un contenedor sin reloj sincronizado puede reportar horas
        que no avanzan, y entonces el conteo por hora falla justo donde
        hace falta.
        """
        return jsonify(servicio=nombre, estado="vivo", version=VERSION_API,
                       instancia=INSTANCIA, arrancado_en=ARRANCADO_EN,
                       segundos_arriba=round(time.time() - _INICIO, 1))

    @app.get("/health/ready")
    def _listo():
        """Sonda de listo, con dependencias esenciales y dependencias opcionales.

        POR QUÉ LA DISTINCIÓN
        ---------------------
        Antes toda dependencia caída daba «no_listo» y 503. El efecto era
        incorrecto en un caso real: algorithms-service lee los agregados de
        PostgreSQL y solo usa MongoDB para guardar el historial de corridas.
        Con MongoDB caído, el motor evalúa perfectamente y responde
        /reglas, /evaluar y /cobertura; sin embargo se declaraba no listo, y
        un orquestador deja de mandarle tráfico a un servicio no listo. Es
        decir: una pieza que funcionaba se sacaba de servicio.

        Ahora hay tres estados en lugar de dos:

          listo      todo responde                      -> 200
          degradado  falla solo una dependencia opcional -> 200
          no_listo   falla una dependencia esencial      -> 503

        «degradado» con 200 es deliberado: el servicio SÍ puede atender, y
        el campo `degradado_por` dice qué dejó de funcionar para que quien
        opera lo vea sin tener que leer bitácoras. Devolver 503 aquí
        esconderia un servicio sano; devolver 200 sin decir nada esconderia
        la falla.

        Una dependencia se declara opcional pasando la tupla
        (función, "opcional") en lugar de la función sola.
        """
        detalle = {}
        esenciales_mal, opcionales_mal = [], []
        for etiqueta, declaracion in comprobaciones.items():
            fn, opcional = declaracion, False
            if isinstance(declaracion, tuple):
                fn, modo = declaracion
                opcional = str(modo).lower() == "opcional"
            # Si esta opcional fallo hace poco, se reintenta con el
            # presupuesto corto: la pregunta ya no es «¿funciona?» sino
            # «¿ya volvio?», y esa se contesta rapido o no se contesta.
            recordado = None
            if opcional:
                with _candado_fallos:
                    guardado = _fallos_opcionales.get(etiqueta)
                if guardado and (time.time() - guardado[0]
                                 < RECUERDO_FALLO_OPCIONAL_S):
                    recordado = guardado

            def _apuntar_causa_tardia(error, _etiqueta=etiqueta):
                """Lo que el cliente dijo cuando por fin contesto.

                Solo sustituye la causa, nunca el veredicto: si vuelve
                con exito se olvida el fallo, y si vuelve con error se
                guarda SU mensaje para que la siguiente sonda diga que
                arreglar en lugar de «no contesto».
                """
                with _candado_fallos:
                    previo = _fallos_opcionales.get(_etiqueta)
                    if error is None:
                        _fallos_opcionales.pop(_etiqueta, None)
                    elif previo is not None:
                        _fallos_opcionales[_etiqueta] = (previo[0],
                                                         str(error)[:200])

            t = time.perf_counter()
            try:
                if opcional:
                    _con_presupuesto(
                        fn,
                        PRESUPUESTO_REINTENTO_S if recordado
                        else PRESUPUESTO_OPCIONAL_S,
                        al_terminar_tarde=_apuntar_causa_tardia)
                else:
                    fn()
                detalle[etiqueta] = {"ok": True, "esencial": not opcional,
                                     "ms": round((time.perf_counter() - t) * 1000, 1)}
                if opcional:
                    # Volvio: se olvida el fallo de inmediato para que la
                    # siguiente sonda ya diga «listo» y no «degradado».
                    with _candado_fallos:
                        _fallos_opcionales.pop(etiqueta, None)
            except Exception as e:
                detalle[etiqueta] = {"ok": False, "esencial": not opcional,
                                     "error": str(e)[:200],
                                     "ms": round((time.perf_counter() - t) * 1000, 1)}
                (opcionales_mal if opcional else esenciales_mal).append(etiqueta)
                if opcional:
                    if recordado:
                        # Sigue caida. Se conserva el PRIMER error, que es
                        # el que explica la causa: el del reintento corto
                        # solo diria «no contesto en 50 ms», que no
                        # informa de nada.
                        detalle[etiqueta]["error"] = recordado[1]
                        detalle[etiqueta]["caida_desde_hace_s"] = round(
                            time.time() - recordado[0], 1)
                        detalle[etiqueta]["nota"] = (
                            "Se reintento con presupuesto corto porque ya "
                            "habia fallado: la pregunta era si ya volvio. "
                            "Sigue caida.")
                        with _candado_fallos:
                            _fallos_opcionales[etiqueta] = recordado
                    else:
                        with _candado_fallos:
                            _fallos_opcionales[etiqueta] = (time.time(),
                                                            str(e)[:200])

        if esenciales_mal:
            estado, codigo = "no_listo", 503
        elif opcionales_mal:
            estado, codigo = "degradado", 200
        else:
            estado, codigo = "listo", 200

        cuerpo = {"servicio": nombre, "estado": estado, "dependencias": detalle,
                  # Las que este servicio NO usa, dichas por su nombre.
                  # Ver el comentario de DEPENDENCIAS_DEL_SISTEMA.
                  "no_aplican": sorted(DEPENDENCIAS_DEL_SISTEMA - set(comprobaciones))}
        if opcionales_mal:
            cuerpo["degradado_por"] = sorted(opcionales_mal)
        if esenciales_mal:
            cuerpo["falta"] = sorted(esenciales_mal)
        return jsonify(cuerpo), codigo

    @app.get("/health")
    def _salud():
        return jsonify(servicio=nombre, descripcion=descripcion,
                       version=VERSION_API, ambiente=ambiente)

    registrar_manejadores(app)
    return app


def cuerpo_peticion(silencioso: bool = True) -> dict:
    """Lee el cuerpo de la petición, venga en JSON o en XML.

    POR QUÉ ESTA FUNCIÓN EXISTE
    ---------------------------
    Los servicios leían el cuerpo con request.get_json(). El efecto era que
    una aplicación cliente que mandara XML recibía un 422 por «campos
    obligatorios» aunque los hubiera mandado todos: get_json() devolvía
    None y el servicio veía un cuerpo vacío. Como la aplicación de
    escritorio del proyecto consume exclusivamente XML, sin esto no podía
    hacer ninguna operación de escritura.

    El formato se decide por Content-Type y no por el contenido: adivinar
    mirando si el primer carácter es '{' o '<' funcionaría casi siempre, y
    el «casi» de un encabezado mal puesto terminaría en un error que nadie
    puede explicar.

    Un cuerpo XML mal formado produce 400 y no 500: es un error del
    cliente, y decírselo con el detalle del parser le permite corregirlo.
    """
    tipo = (request.content_type or "").split(";")[0].strip().lower()
    if tipo in ("application/xml", "text/xml"):
        from .xmlizar import de_xml
        crudo = request.get_data(as_text=True)
        if not crudo.strip():
            return {}
        try:
            datos = de_xml(crudo)
        except ValueError as e:
            raise ErrorApi("XML_MAL_FORMADO", str(e), 400)
        if not isinstance(datos, dict):
            raise ErrorApi(
                "XML_INESPERADO",
                "El elemento raiz del cuerpo tiene que contener los campos "
                "como elementos hijos.", 400)
        return datos
    datos = request.get_json(silent=silencioso) or {}
    return datos if isinstance(datos, dict) else {}
