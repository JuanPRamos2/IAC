# Tercer parcial — Emiliano y Gerardo

Proyecto 4. Plataforma de Bienestar Laboral y Prevención de Burnout
Integración de Aplicaciones Computacionales · UDEM · Equipo 03

| | |
|---|---|
| Emiliano Pascual Piñales Sánchez | #657657 · Integrante 3 — algoritmos, bases de datos y pruebas de rendimiento |
| Gerardo Quiroga Ramírez | #650313 · Integrante 4 — aplicaciones cliente e integración completa |

Este paquete trae **solo la parte de Emiliano y Gerardo**. Los componentes
de los integrantes 1 y 2 están tal como los entregaron.

---

## Qué leer primero

| Documento | De qué es |
|---|---|
| `Algoritmo_Complejo_Equipo03.md` | El algoritmo: problema, entradas, salidas, variables, restricciones, complejidad, pseudocódigo, 31 casos de prueba, métricas, limitaciones y tiempo de ejecución |
| `Rendimiento_y_Carga_Equipo03.md` | Datos masivos, índices, optimización de consultas, caché con y sin Redis, y las pruebas de carga con Locust |
| `Clientes_e_Integracion_Equipo03.md` | Los tres procesos integrales, las aplicaciones cliente y el manejo de errores, permisos y fallos de conexión |

Y en `documentos/expediente/`, los capítulos que nos tocaban del
expediente de 32 apartados, más la bitácora, el registro de incidencias y
los guiones de láminas:

| Archivo | De quién |
|---|---|
| `E1_Modelo_de_Agregados_e_Indices.md` | Emiliano |
| `E2_Reglas_de_k_Minimo_y_Ruido.md` | Emiliano |
| `E3_Algoritmos.md` | Emiliano |
| `E4_Resultados_de_Locust.md` | Emiliano |
| `E5_Resultados_de_Rendimiento.md` | Emiliano |
| `G1_Mapa_de_los_24_Microservicios.md` | Gerardo |
| `G2_Monitoreo.md` | Gerardo |
| `G3_MongoDB.md` | Gerardo |
| `G4_Contratos_XML_del_Escritorio.md` | Gerardo |
| `G5_Diseno_del_Bucket_Servicio.md` | Gerardo (la otra mitad, la de GCP, es de Juan Pablo) |
| `G6_Manual_Tecnico_de_la_Laptop.md` | Gerardo |
| `G7_Manual_de_Usuario.md` | Gerardo |
| `Bitacora_Emiliano_y_Gerardo.md` | los dos (Ricardo junta las cuatro) |
| `Registro_de_Incidencias.md` | abierto por Gerardo con tres; los demás agregan |
| `Laminas_Emiliano.md` · `Laminas_Gerardo.md` | guiones de las láminas, con lo que se dice de viva voz |
| `Guion_del_Ensayo_de_Fallos.md` | las seis situaciones × las cinco cosas que hay que poder explicar, con dónde está la evidencia de cada una |
| `Reflexion_Emiliano.md` · `Reflexion_Gerardo.md` | **borradores**: el material real de cada uno, ordenado. Cada quien lo reescribe en su voz y lo sube él mismo |
| `Estado_de_Cierre_Emiliano_y_Gerardo.md` | **lee éste primero**: qué quedó hecho, qué falta, de quién es cada cosa |
| `Guion_de_Capturas_y_Grabaciones.md` | las capturas y grabaciones que faltan, con qué cuenta y qué tiene que verse en cada una |

Y para lo que falta en la máquina virtual, **un solo comando**:

```bash
bash scripts/corrida_en_la_nube.sh     # generador + Locust x2, deja todo en informes/nube/
```

---

## Cómo levantarlo

```bash
docker compose up -d --build        # los 24 microservicios, PostgreSQL, Redis y MongoDB
python3 -m pytest pruebas/ -q       # 625 pruebas, 623 pasan y 2 se omiten
```

Sin Docker, para la demostración:

```bash
./scripts/arrancar_microservicios.sh
```

Para reproducir las mediciones de rendimiento:

```bash
# 1. Datos masivos: 26 526 empleados, 206 231 respuestas, 1 031 155 valores
python3 scripts/datos_masivos.py --base nexum_carga --unidades 120 --campanias 12

# 2. Índices, planes de ejecución y caché
python3 scripts/rendimiento.py --base nexum_carga --salida rendimiento.json

# 3. El detector contra la verdad inyectada
python3 scripts/validar_algoritmo.py --base nexum_carga

# 4. Carga. Las cuentas hacen falta: ver el comentario del guión
psql -d nexum_carga -f scripts/cuentas_de_carga.sql
cd pruebas/carga && NEXUM_FORMA=rampa locust -f locustfile.py --headless
```

---

## Lo que se midió

**El algoritmo complejo**, contra señal inyectada a propósito en 110
unidades (5% deterioradas y 5% decayendo, anotadas antes de correr nada):

| | |
|---|---|
| Hallazgos de segmento | precisión 100%, exhaustividad 100% |
| Deterioro sostenido | precisión 83.3%, exhaustividad 100% |
| Ranking, top 5 | 5 de 5 inyectadas |
| Épsilon consumido | 0.0 |
| Tiempo | 69 ms sobre 110 unidades |

**Rendimiento**, antes y después:

| | antes | después |
|---|---|---|
| `fn_calcular_agregado_protegido` (7 920 llamadas por organización) | 89 ms | 21 ms |
| `/consultas/presupuesto` | 458 ms | 4.6 ms |
| Panel de monitoreo | 1 635 ms | 2.8 ms |
| Sonda de salud con dependencia opcional caída | 1 286 ms | 53 ms |
| p95 de la corrida de carga | 1 500 ms | 40 ms |
| Errores de la corrida de carga | 42.0% | 0.02% |

**Consumo de recursos** con un millón de valores, medido en el proceso
servidor de PostgreSQL y no en el cliente:

| | |
|---|---|
| CPU / reloj por consulta | 73 % a 100 %: ninguna espera disco |
| Derrames a `work_mem` | ninguno; pico de 49 kB contra 4 MB |
| Memoria del backend | 27 MB, pico 27 MB, plana en las seis consultas |
| Inserción con `COPY` | 100 000 filas/s |
| Cálculo de agregados | 68 ms cada uno, backend al **99 % de CPU** |

La conclusión que sólo da el CPU: los agregados están **limitados por
cómputo**, no por disco. Ni un disco más rápido ni otro índice los mejoran;
la palanca es el paralelismo, porque las llamadas son independientes.

**Carga**: 140 usuarios concurrentes con mediana plana en 14 ms y
recuperación inmediata. Apretando seis veces más: 197 peticiones/segundo,
p95 de 400 ms y **cero errores 5xx** — las 3 917 fallas fueron todas 429,
rechazos deliberados del limitador.

---

## Los defectos que encontró este trabajo

Diecinueve, y ninguno se veía con los datos de demostración. Están
explicados en los tres documentos; en una línea cada uno:

**Del algoritmo** (4): k-medias agrupaba las unidades deterioradas y
dentro de su grupo parecían normales; con datos masivos el ruido baja
tanto que todo salía significativo y marcaba 36 hallazgos de 0.12 puntos;
el nivel salía de un promedio que diluía las señales fuertes; y «empeorar»
se confundía con «bajar», así que una mejora en carga percibida contaba
como deterioro.

**De rendimiento en PostgreSQL** (3): un índice inerte porque el
`ORDER BY` de una vista tenía una tercera clave que el índice no cubría;
una subconsulta correlacionada sin índice que recorría una tabla 1 372
veces; y el panel de monitoreo retenía un obrero del proceso 1.4 s, lo que
llevaba `/monitoreo/errores` de 5 ms a 2 549 ms.

**De rendimiento en MongoDB** (6): seis consultas de 44 sin índice detrás,
encontradas analizando el código porque MongoDB no está en este ambiente y
no hay `explain()`. Entre ellas, la de **cada descarga de evidencia** y el
endpoint que más llama la aplicación móvil. Cuatro de las seis eran
ordenamientos sin índice, que es el caso que **no se degrada sino que
falla**: el sort en memoria tiene un límite de 32 MB.

**De integración** (4): el especialista podía aprobar su propio plan de
intervención; `documents-service` devolvía 500 con un error de Python
cuando el cliente mandaba el tipo correcto; la ruta del objeto en Cloud
Storage se calculaba dos veces y coincidía por casualidad; y cualquier
camino de escritura podía romper la invariante de la jerarquía, que es lo
que sostiene el control de inferencia.

**De observabilidad y límites** (6): la sonda de salud no comprobaba el
**bucket**, así que un `documents-service` con el almacén caído contestaba
«listo», aceptaba una carga, escribía los metadatos y fallaba al escribir
el blob —dejando un documento registrado cuyo archivo no existe—; el panel
no tenía **historial de disponibilidad**, de modo que un servicio que se
cae y se levanta no dejaba rastro; no existía ningún **tiempo máximo por
petición** más que el de gunicorn, que mata al obrero sin contestar nada;
y los tests de los clientes convertían un servicio **roto** en un `skip`,
lo que dejó pasar en verde una rotura real de quince casos. Y dos más que
aparecieron al comprobar las afirmaciones del propio documento: el corte
por tiempo estaba puesto **sólo en la parte barata** del análisis —armar
las series— y no en el motor, que es donde se gasta el tiempo, así que no
habría disparado nunca donde importa; y una conexión muerta a PostgreSQL
tras un reinicio salía como **500 «error interno»** en lugar de 503, lo
que dice «el código está roto» cuando la base sólo se reinició y el pool
ya se recupera solo.

**Errores de medición propios** (3, porque un informe equivocado es un
defecto): el banco de pruebas elegía la unidad con `ORDER BY random()`, y
dos corridas de la misma base daban 15.85 ms y 226.41 ms del mismo camino;
la medición de CPU no superaba la resolución del reloj del kernel y
reportaba «0.00 ms» —que se lee como «no consume CPU»— y hasta 2.86 ms de
CPU para 0.34 ms de reloj, que es imposible; y el conteo de filas leía
estimaciones que decían 0 y 5 para tablas con 1 031 155 y 8 299 filas.

Y tres migraciones nuevas: **018** (análisis complejo e índices), **019**
(control de cuatro ojos en la aprobación) y **020** (la invariante de la
jerarquía pasa de comprobarse a impedirse). La migración 020 rompió al
cargar la base desde cero con semilla —el árbol se carga por partes y el
padre se recalcula al final—, y se corrigió aplazando la comprobación al
`COMMIT`, que es comprobarla igual, sobre el árbol ya armado.

---

## Lo que NO está, y de quién depende

**El despliegue en GCP.** Es del Integrante 1 y en el código que se
integró no existe. Lo que esta parte podía dejar hecho está hecho: los
clientes no llevan ninguna dirección fija —variables de ambiente en el
escritorio, `buildConfigField` en el móvil con una variante de
producción—, `documents-service` firma direcciones de Cloud Storage cuando
se le dan `GCS_BUCKET` y `GOOGLE_APPLICATION_CREDENTIALS`, y
`docker-compose.gcp.yml` ya quita los puertos publicados. Lo que no se
puede hacer desde aquí es crear el bucket, la cuenta de servicio y las
máquinas.

**MongoDB en el ambiente de medición.** No se pudo instalar, así que 7 de
los 24 servicios quedan `no_listo` y sus endpoints no se midieron. La
prueba de carga los salta e imprime cuáles, en lugar de contar sus 503
como errores de capacidad. `algorithms-service` sí se midió: queda
`degradado` y atiende, que es para lo que existen los tres estados de la
sonda.
