/**
 * Serializacion dual JSON/XML de main-process-service.
 * Delega en comun para que las reglas sean las mismas que en los otros
 * siete microservicios y un solo XSD las describa.
 */
import { responder } from "@bienestar/comun/servicio.js";

export function responderProceso(req, res, datos, { rootTag = "proceso", status = 200 } = {}) {
  return responder(req, res, datos, { http: status, raiz: rootTag });
}
